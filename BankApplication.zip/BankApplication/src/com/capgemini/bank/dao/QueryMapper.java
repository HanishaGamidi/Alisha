package com.capgemini.bank.dao;

public interface QueryMapper {
	
	public static final String INSERT_QUERY="INSERT INTO demand_draft VALUES( transaction_id_seq.NEXTVAL,?,?,?,SYSDATE,?,?,?)";
	public static final String TRANS_ID_QUERY_SEQUENCE="SELECT  Transaction_id_Seq.CURRVAL FROM DUAL";
	public static final String GET_DRAFT_DETAILS_QUERY="SELECT customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount, dd_commission, dd_description FROM demand_draft WHERE transaction_id=?";
	

}
