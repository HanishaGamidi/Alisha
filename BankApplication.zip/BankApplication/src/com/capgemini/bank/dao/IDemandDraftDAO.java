package com.capgemini.bank.dao;

import com.capgemini.bank.Exception.DemandDraftException;
import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftDAO {
	
	public String addDemandDraftDetails(DemandDraft demandDraft)throws DemandDraftException;
    public DemandDraft getDemandDraftDetails(String transaction_id)throws DemandDraftException;

}
