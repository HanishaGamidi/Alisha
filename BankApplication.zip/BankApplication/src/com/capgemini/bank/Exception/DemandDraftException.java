package com.capgemini.bank.Exception;

public class DemandDraftException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DemandDraftException(String message) {
		
		super(message);
	}

}
