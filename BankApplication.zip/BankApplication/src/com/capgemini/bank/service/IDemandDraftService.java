package com.capgemini.bank.service;

import com.capgemini.bank.Exception.DemandDraftException;
import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService {
	
	public String addDemandDraftDetails (DemandDraft demandDraft)throws DemandDraftException;
	public DemandDraft getDemandDraftDetails (String transaction_id) throws DemandDraftException;
	

}
